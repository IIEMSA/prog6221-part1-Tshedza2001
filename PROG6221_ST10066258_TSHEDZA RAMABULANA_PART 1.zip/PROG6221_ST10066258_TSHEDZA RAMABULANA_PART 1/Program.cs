﻿using System;

class RecipeAppication
{
    private static string[] ingredientsNames; // array to store the ingredient names
    private static double[] ingredientAmount; // array to store the ingredient quantities
    private static string[] unitMeasurements; // array to store the unit of measurement for each ingredient
    private static string[] recipeSteps; // array to store the recipe steps

    static void Main(string[] args)
    {
        //This brings the colour Red to the below text
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        Console.WriteLine("|        Welcome to the Recipe Application        |");
        Console.WriteLine("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        Console.ResetColor(); // Reset the text color to default

        bool quit = false;
        while (!quit)
        {

            // Display menu options to the user
            Console.WriteLine("Please select one of the following options!");
            Console.WriteLine("1. Enter a new recipe");
            Console.WriteLine("2. Scale the recipe");
            Console.WriteLine("3. Reset the recipe");
            Console.WriteLine("4. Clear all data");
            Console.WriteLine("5. Quit");

            // Read user input and execute the corresponding function
            string input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    EnterRecipe();
                    break;
                case "2":
                    ScaleRecipe();
                    break;
                case "3":
                    ResetRecipe();
                    break;
                case "4":
                    ClearData();
                    break;
                case "5":
                    quit = true;
                    break;
                default:
                    Console.WriteLine("Invalid input, please try again");
                    break;
            }
        }
    }

    static void EnterRecipe()
    {
        // Prompt the user for the number of ingredients and steps in the recipe
        Console.WriteLine("Enter the number of ingredients:");
        int ingredientNumbers = int.Parse(Console.ReadLine());

        // Create new arrays to store the recipe information based on the number of ingredients and steps
        ingredientsNames = new string[ingredientNumbers];
        ingredientAmount = new double[ingredientNumbers];
        unitMeasurements = new string[ingredientNumbers];

        // Prompt the user for each ingredient and quantity, and store the information in the appropriate arrays
        for (int i = 0; i < ingredientNumbers; i++)
        {
            Console.WriteLine($"Ingredient number {i + 1}");
            Console.Write("Name: ");
            ingredientsNames[i] = Console.ReadLine();
            Console.Write("Quantity of the ingredient: ");
            ingredientAmount[i] = double.Parse(Console.ReadLine());
            Console.Write("Unit of measurement of the ingredient: ");
            unitMeasurements[i] = Console.ReadLine();
        }

        // Prompt the user for each step in the recipe, and store the steps in the steps array
        Console.WriteLine("Enter the number of steps:");
        int recipeStepsNumber = int.Parse(Console.ReadLine());

        recipeSteps = new string[recipeStepsNumber];

        for (int i = 0; i < recipeStepsNumber; i++)
        {
            Console.WriteLine($"Step #{i + 1}:");
            recipeSteps[i] = Console.ReadLine();
        }

        // Display the recipe to the user using the DisplayRecipe() function
        DisplayRecipe();
    }

    static void DisplayRecipe()
    {

        //This brings the colour yellow to the below text
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\nRecipe:");
        for (int i = 0; i < ingredientsNames.Length; i++)
        {

            //This brings the colour green to the below text
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{ingredientAmount[i]} {unitMeasurements[i]} {ingredientsNames[i]}");
            Console.ResetColor(); // Reset the text color to default
        }
        Console.WriteLine();
        for (int i = 0; i < recipeSteps.Length; i++)
        {

            //This brings the colour Cyan to the below text
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"{i + 1}. {recipeSteps[i]}");
            Console.ResetColor(); // Reset the text color to default
        }
    }
    static void ScaleRecipe()
    {
        // Prompt the user for the scaling factor
        Console.WriteLine("Enter the scaling factor (0.5, 2, or 3):");
        double factor = double.Parse(Console.ReadLine());

        // Multiply each ingredient quantity by the scaling factor
        for (int i = 0; i < ingredientAmount.Length; i++)
        {
            ingredientAmount[i] *= factor;
        }

        //This displays the recipe
        DisplayRecipe();
    }

    static void ResetRecipe()
    {
        //Displays the recipe after it has been reset.
        DisplayRecipe();
    }

    static void ClearData()
    {
        //This allows the user to choose an option on wether to clear the data or not.
        Console.WriteLine("Are you sure you want to clear all data? (Y/N)");
        string userInput = Console.ReadLine().ToUpper();

        if (userInput == "Y" || userInput == "YES")
        {
            ingredientsNames = null;
            ingredientAmount = null;
            unitMeasurements = null;
            recipeSteps = null;

            Console.WriteLine("Data cleared.");
        }
        else
        {
            Console.WriteLine("Data not cleared.");
        }
    }
}